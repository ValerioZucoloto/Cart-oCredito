using System;

class Cartao {
        public string Bandeira { get; private set; }
        public bool Desbloqueado { get; set; }
        public double Saldo { get; set; }
        public double Limite { get; private set; }


        public Cartao (string bandeira, double limite) {
                Bandeira = bandeira;
                Desbloqueado = true;
                Saldo = 0.0;
                Limite = limite;
        }

        public double consultarLimite() {
                return Limite;
        }

        public double consultarSaldo() {
                return Saldo;
        }

        public string getEstadoCartao() {
                string estado = "Bloqueado";

                if (Desbloqueado) {
                        estado = "Desbloqueado";
                }

                return estado;
        }

        public override string ToString() {
                return "\nBandeira: " + Bandeira 
                + "\nSaldo: " + Saldo
                + "\nLimite: " + Limite
                + "\nEstado: " + getEstadoCartao();
        }

}