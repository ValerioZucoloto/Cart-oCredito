using System;

class Maquina{
        public string Fabricante { get; private set; }
        public string Estabelecimento { get; set; }

        public Maquina (string fabricante, string estabelecimento) {
                Fabricante = fabricante;
                Estabelecimento = estabelecimento;
        }
}