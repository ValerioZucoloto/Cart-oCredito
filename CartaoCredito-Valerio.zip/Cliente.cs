using System;

class Cliente {
        public string Nome { get; set; }
        public string Cpf { get; private set; }
        public Cartao meuCartao { get; set; }

        public Cliente (string nome, string cpf, Cartao cartao) {
                Nome = nome;
                Cpf = cpf;
                meuCartao = cartao;
        }

        public override string ToString() {
                return "\nNome: " + Nome
                + "\nCpf: " + Cpf
                + meuCartao;
        }
}