using System;

class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine();

    Cartao Santander = new Cartao ("Mastercard", 1000);
    Cliente Joao = new Cliente ("João", "123456789", Santander);

    Console.WriteLine (Joao);
  }
}